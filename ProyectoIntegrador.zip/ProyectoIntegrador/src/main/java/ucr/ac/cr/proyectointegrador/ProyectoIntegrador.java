/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package ucr.ac.cr.proyectointegrador;

import ucr.ac.cr.proyectointegrador.controller.LoginController;

/**
 *
 * @author familiacr
 */
public class ProyectoIntegrador {

    public static void main(String[] args) {
        new LoginController();
    }
}
